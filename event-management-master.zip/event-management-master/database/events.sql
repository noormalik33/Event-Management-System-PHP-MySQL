-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/

-- Server version: 10.1.34-MariaDB
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";

-- Character settings
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

-- --------------------------------------------------------
-- Database: `csefest`
-- --------------------------------------------------------

-- Drop tables if exist (for clean re-import)
DROP TABLE IF EXISTS `registration`, `participants`, `events`, `event_type`, `college`, `users`;

-- --------------------------------------------------------
-- Table structure for table `users`
-- --------------------------------------------------------
CREATE TABLE `users` (
  `user_id` INT(11) NOT NULL AUTO_INCREMENT,
  `username` VARCHAR(100) NOT NULL,
  `password` VARCHAR(255) NOT NULL,
  `role` ENUM('admin', 'participant') NOT NULL DEFAULT 'participant',
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Sample data for `users`
INSERT INTO `users` (`username`, `password`, `role`) VALUES
('admin1', 'adminpass123', 'admin'),
('john_doe', 'userpass456', 'participant');

-- --------------------------------------------------------
-- Table structure for table `college`
-- --------------------------------------------------------
CREATE TABLE `college` (
  `college_id` INT(11) NOT NULL AUTO_INCREMENT,
  `college_name` VARCHAR(255) NOT NULL,
  PRIMARY KEY (`college_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Sample data for `college`
INSERT INTO `college` (`college_name`) VALUES
('ABC Engineering College'),
('XYZ Institute of Technology'),
('LMN College of Science');

-- --------------------------------------------------------
-- Table structure for table `event_type`
-- --------------------------------------------------------
CREATE TABLE `event_type` (
  `type_id` INT(10) NOT NULL AUTO_INCREMENT,
  `type_title` TEXT NOT NULL,
  PRIMARY KEY (`type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Sample data for `event_type`
INSERT INTO `event_type` (`type_title`) VALUES
('Technical Events'),
('Gaming Events'),
('On Stage Events'),
('Off Stage Events'),
('New Event Type');

-- --------------------------------------------------------
-- Table structure for table `events`
-- --------------------------------------------------------
CREATE TABLE `events` (
  `event_id` INT(100) NOT NULL AUTO_INCREMENT,
  `event_title` TEXT NOT NULL,
  `event_price` INT(20) NOT NULL,
  `participents` INT(100) NOT NULL,
  `img_link` TEXT NOT NULL,
  `type_id` INT(100) NOT NULL,
  PRIMARY KEY (`event_id`),
  FOREIGN KEY (`type_id`) REFERENCES `event_type`(`type_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Sample data for `events`
INSERT INTO `events` (`event_title`, `event_price`, `participents`, `img_link`, `type_id`) VALUES
('pubg', 50, 4, 'cs01.jpg', 2),
('tech quiz', 50, 2, 'cs02.jpg', 1),
('counter strike', 50, 1, 'cs03.jpg', 2),
('pair programming', 50, 2, 'cs01.jpg', 1),
('seminar', 50, 1, 'cs02.jpg', 3),
('multiple choice', 50, 1, 'cs01.jpg', 4);

-- --------------------------------------------------------
-- Table structure for table `participants`
-- --------------------------------------------------------
CREATE TABLE `participants` (
  `p_id` INT(10) NOT NULL AUTO_INCREMENT,
  `event_id` INT(10) NOT NULL,
  `fullname` VARCHAR(100) NOT NULL,
  `email` VARCHAR(300) NOT NULL,
  `mobile` VARCHAR(10) NOT NULL,
  `college_id` INT(11) NOT NULL,
  `branch` VARCHAR(100) NOT NULL,
  PRIMARY KEY (`p_id`),
  FOREIGN KEY (`event_id`) REFERENCES `events`(`event_id`) ON DELETE CASCADE,
  FOREIGN KEY (`college_id`) REFERENCES `college`(`college_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Sample data for `participants`
INSERT INTO `participants` (`event_id`, `fullname`, `email`, `mobile`, `college_id`, `branch`) VALUES
(1, 'Ishrat Smith', 'ishrat@email.com', '1234567890', 1, 'CSE'),
(2, 'Muqeem Ali', 'muqeem@email.com', '2345678901', 2, 'ECE'),
(3, 'Kamran Ahmed', 'kamran@email.com', '3456789012', 1, 'IT');

-- --------------------------------------------------------
-- Table structure for table `registration`
-- --------------------------------------------------------
CREATE TABLE `registration` (
  `registration_id` INT(11) NOT NULL AUTO_INCREMENT,
  `p_id` INT(10) NOT NULL,
  `event_id` INT(10) NOT NULL,
  `reg_date` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`registration_id`),
  FOREIGN KEY (`p_id`) REFERENCES `participants`(`p_id`) ON DELETE CASCADE,
  FOREIGN KEY (`event_id`) REFERENCES `events`(`event_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Sample data for `registration`
INSERT INTO `registration` (`p_id`, `event_id`) VALUES
(1, 1),
(2, 2),
(2, 3),
(3, 1),
(3, 4);

-- --------------------------------------------------------
-- AUTO_INCREMENT values
-- --------------------------------------------------------
ALTER TABLE `events` AUTO_INCREMENT = 7;
ALTER TABLE `event_type` AUTO_INCREMENT = 6;
ALTER TABLE `participants` AUTO_INCREMENT = 4;
ALTER TABLE `registration` AUTO_INCREMENT = 6;
ALTER TABLE `college` AUTO_INCREMENT = 4;
ALTER TABLE `users` AUTO_INCREMENT = 3;

COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
\