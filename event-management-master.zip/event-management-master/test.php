<?php echo "Hello from XAMPP"; ?>
