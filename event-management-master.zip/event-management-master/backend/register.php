<?php
session_start();

// Database connection
$con = mysqli_connect("localhost", "root", "", "csefest");
if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $full_name = mysqli_real_escape_string($con, $_POST["full_name"] ?? '');
    $email = mysqli_real_escape_string($con, $_POST["email"] ?? '');
    $mobile = mysqli_real_escape_string($con, $_POST["mobile"] ?? '');
    $college_id = intval($_POST["college_id"] ?? 0);
    $branch = mysqli_real_escape_string($con, $_POST["branch"] ?? '');
    $event_id = intval($_POST["event_id"] ?: ($_GET["event_id"] ?? 0));
    $event_price = floatval($_POST["event_price"] ?? 0);

    if (empty($full_name) || empty($email) || empty($mobile) || empty($branch) || $event_id === 0 || $college_id === 0) {
        echo "<div class='alert alert-warning'><b>Please fill all required fields!</b></div>";
    } else {
        $check_query = "SELECT * FROM participants WHERE email = '$email' AND event_id = $event_id";
        $check_result = mysqli_query($con, $check_query);

        if (mysqli_num_rows($check_result) > 0) {
            echo "<div class='alert alert-warning'>You are already registered for this event!</div>";
        } else {
            $insert_participant = "INSERT INTO participants (event_id, fullname, email, mobile, college_id, branch)
                                  VALUES ($event_id, '$full_name', '$email', '$mobile', $college_id, '$branch')";

            if (mysqli_query($con, $insert_participant)) {
                $participant_id = mysqli_insert_id($con);
                $current_date = date('Y-m-d H:i:s');
                $insert_registration = "INSERT INTO registration (p_id, event_id, reg_date)
                                       VALUES ($participant_id, $event_id, '$current_date')";

                if (mysqli_query($con, $insert_registration)) {
                    $update_event = "UPDATE events SET participants = participants + 1 WHERE event_id = $event_id";
                    mysqli_query($con, $update_event);
                    echo "<div class='alert alert-success'>Registration successful!</div>";
                } else {
                    echo "<div class='alert alert-danger'>Error in registration: " . mysqli_error($con) . "</div>";
                }
            } else {
                echo "<div class='alert alert-danger'>Error saving participant: " . mysqli_error($con) . "</div>";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Event Registration</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
    <style>
        body { background-color: #f8f9fa; }
        .registration-container { max-width: 800px; margin: 30px auto; background: white; padding: 30px; border-radius: 10px; box-shadow: 0 0 20px rgba(0,0,0,0.1); }
        .form-group { margin-bottom: 1.5rem; }
        .event-price { font-weight: bold; color: #28a745; }
    </style>
</head>
<body>
<div class="registration-container">
    <h2 class="text-center mb-4">Event Registration Form</h2>
    <form method="POST" action="">
        <div class="form-row">
            <div class="form-group col-md-6">
                <label>Full Name:</label>
                <input type="text" name="full_name" class="form-control" required>
            </div>
            <div class="form-group col-md-6">
                <label>Email Address:</label>
                <input type="email" name="email" class="form-control" required>
            </div>
        </div>

        <div class="form-row">
            <div class="form-group col-md-6">
                <label>Mobile Number:</label>
                <input type="text" name="mobile" class="form-control" required maxlength="10" pattern="[0-9]{10}" title="10 digit mobile number">
            </div>
            <div class="form-group col-md-6">
                <label>Branch:</label>
                <input type="text" name="branch" class="form-control" required>
            </div>
        </div>

        <div class="form-row">
            <div class="form-group col-md-6">
                <label>College:</label>
                <select name="college_id" class="form-control" required>
                    <option value="">-- Select College --</option>
                    <?php
                    $colleges = mysqli_query($con, "SELECT * FROM college");
                    while ($college = mysqli_fetch_assoc($colleges)) {
                        echo "<option value='" . $college['college_id'] . "'>" . $college['college_name'] . "</option>";
                    }
                    ?>
                </select>
            </div>
            <div class="form-group col-md-6">
                <label>Event:</label>
                <select name="event_id" id="event_select" class="form-control" required onchange="updateEventPrice()">
                    <option value="">-- Select Event --</option>
                    <?php
                    $events = mysqli_query($con, "SELECT e.*, et.type_title FROM events e JOIN event_type et ON e.type_id = et.type_id");
                    while ($event = mysqli_fetch_assoc($events)) {
                        echo "<option value='" . $event['event_id'] . "' data-price='" . $event['event_price'] . "' data-type='" . $event['type_title'] . "'>" 
                            . $event['event_title'] . " (" . $event['type_title'] . ")</option>";
                    }
                    ?>
                </select>
            </div>
        </div>

        <div class="form-group">
            <div class="alert alert-info">
                Event Price: <span id="event_price_display" class="event-price">₹0.00</span>
                <input type="hidden" name="event_price" id="event_price" value="0">
            </div>
        </div>

        <button type="submit" class="btn btn-primary btn-block btn-lg">Complete Registration</button>
    </form>
</div>

<script>
function updateEventPrice() {
    const select = document.getElementById('event_select');
    const priceDisplay = document.getElementById('event_price_display');
    const priceInput = document.getElementById('event_price');

    if (select.value) {
        const price = select.options[select.selectedIndex].getAttribute('data-price');
        priceDisplay.textContent = '₹' + parseFloat(price).toFixed(2);
        priceInput.value = price;
    } else {
        priceDisplay.textContent = '₹0.00';
        priceInput.value = 0;
    }
}

window.onload = function () {
    const urlParams = new URLSearchParams(window.location.search);
    const eventId = urlParams.get("event_id");

    if (eventId) {
        const select = document.getElementById("event_select");
        for (let i = 0; i < select.options.length; i++) {
            if (select.options[i].value === eventId) {
                select.selectedIndex = i;
                break;
            }
        }
        updateEventPrice();
    }
};
</script>
</body>
</html>
